package trading;
import prices.Price;


public class Order implements Tradable 
{
	private String userName;
	
	private String productSymbol;
	
	private String id;
	
	private String side;
	
	private Price orderPrice;
	
	private int originalVolume;
	
	private int remainingVolume;
	
	private int cancelledVolume;
	
	public Order(String userName, String productSymbol, Price orderPrice, int originalVolume, String side) 
			throws InvalidOrderVolumeException, InvalidUserNameException, InvalidProductSymbolException, 
			InvalidPriceException, InvalidRemainingVolumeException, InvalidSideException, InvalidIdException
	{
		this.setUserName(userName);
		this.setProductSymbol(productSymbol);
		this.setPrice(orderPrice);
		this.setOriginalVolume(originalVolume);
		this.setRemainingVolume(originalVolume);
		this.setSide(side);
		this.setId(userName + productSymbol + orderPrice.toString() + System.nanoTime());
	}
	
	@Override
	public String getProduct() 
	{
		return productSymbol;
	}

	@Override
	public Price getPrice() 
	{
		return orderPrice;
	}
	
	@Override
	public int getOriginalVolume() 
	{
		return originalVolume;
	}

	@Override
	public int getRemainingVolume() 
	{
		return remainingVolume;
	}

	@Override
	public int getCancelledVolume() 
	{
		return cancelledVolume;
	}

	@Override
	public void setCancelledVolume(int newCancelledVolume) throws InvalidCancelledVolumeException 
	{
		if (newCancelledVolume > this.originalVolume || newCancelledVolume < 0)
		{
			throw new InvalidCancelledVolumeException(newCancelledVolume, this.remainingVolume, this.originalVolume);
		}
		
		this.cancelledVolume = newCancelledVolume;
	}

	@Override
	public void setRemainingVolume(int newRemainingVolume) throws InvalidRemainingVolumeException 
	{
		if (newRemainingVolume > this.originalVolume || newRemainingVolume < 0)
		{
			throw new InvalidRemainingVolumeException(newRemainingVolume, this.cancelledVolume, this.originalVolume);
		}
		
		this.remainingVolume = newRemainingVolume;
	}
	
	private void setOriginalVolume(int originalVolume) throws InvalidOrderVolumeException
	{
		if (originalVolume <= 0)
		{
			throw new InvalidOrderVolumeException(originalVolume);
		}
		
		this.originalVolume = originalVolume;
	}
	
	
	private void setUserName(String userName) throws InvalidUserNameException
	{
		if (userName == null || userName == "")
		{
			throw new InvalidUserNameException("User names cannot be empty or null");
		}

		this.userName = userName.toUpperCase().trim();
	}
	
	private void setProductSymbol(String productSymbol) throws InvalidProductSymbolException
	{
		if (productSymbol == null || productSymbol == "")
		{
			throw new InvalidProductSymbolException("Product symbols cannot be empty or null");
		}

		this.productSymbol = productSymbol.toUpperCase().trim();
	}
	
	private void setSide(String side) throws InvalidSideException
	{
		side = side.toUpperCase().trim();
		
		if (side == null || side == "" || (side != "BUY" && side != "SELL"))
		{
			throw new InvalidSideException("Side must be \"BUY\" or \"SELL\"");
		}
		
		this.side = side;
	}
	
	private void setPrice(Price price) throws InvalidPriceException
	{
		if (price == null)
		{
			throw new InvalidPriceException("Price must be a valid Market or Limit Price");
		}
		
		this.orderPrice = price;
	}
	
	private void setId(String id) throws InvalidIdException
	{
		if (id == null)
		{
			throw new InvalidIdException("Id cannot be null");
		}
		
		this.id = id;
	}

	@Override
	public String getUser() 
	{
		return userName;
	}

	@Override
	public String getSide() 
	{
		return side;
	}

	@Override
	public String getId() 
	{
		return id;
	}
	
	@Override
	public boolean isQuote() 
	{
		return false;
	}
	
	public String toString()
	{
		return String.format("%s order: %s %d %s at %s (Original Vol: %d, CXL'd: %d), ID: %s", 
				userName, side, remainingVolume, productSymbol, orderPrice.toString(), originalVolume, cancelledVolume, id);
	}	

}
