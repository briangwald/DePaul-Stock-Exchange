package trading;

@SuppressWarnings("serial")
public class InvalidPriceException extends Exception 
{
	public InvalidPriceException(String err)
	{
		super(err);
	}
}
