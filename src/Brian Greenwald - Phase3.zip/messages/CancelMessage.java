package messages;

import prices.Price;
import trading.InvalidIdException;
import trading.InvalidPriceException;
import trading.InvalidProductSymbolException;
import trading.InvalidSideException;
import trading.InvalidUserNameException;

public class CancelMessage extends Message implements Comparable<CancelMessage>
{

	public CancelMessage(String userName, String productSymbol, Price price, int volume, String details, String side, String id)
			throws InvalidUserNameException, InvalidProductSymbolException,
			InvalidPriceException, InvalidVolumeException,
			InvalidDetailsException, InvalidSideException, InvalidIdException 
	{
		super(userName, productSymbol, price, volume, details, side, id);
	}

	public int compareTo(CancelMessage cm) 
	{
		return this.getPrice().compareTo(cm.getPrice());
	}
	
}
