package trading;

@SuppressWarnings("serial")
public class InvalidRemainingVolumeException extends Exception 
{
	public InvalidRemainingVolumeException(int newRemainingVolume, int cancelledVolume, int originalVolume)
	{
		super(String.format("Requested new Remaining Volume (%d) plus the Cancelled Volume (%d) "
				+ "exceeds the tradable's Original Volume (%d)", newRemainingVolume, cancelledVolume, originalVolume));
	}
}
