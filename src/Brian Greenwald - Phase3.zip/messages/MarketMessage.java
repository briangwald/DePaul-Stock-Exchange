package messages;

public class MarketMessage 
{
	private String state;
	
	public MarketMessage(String state) throws InvalidMarketStateException
	{
		this.setState(state);
	}
	
	private void setState(String state) throws InvalidMarketStateException
	{
		if (state == null || state == "")
		{
			throw new InvalidMarketStateException("Market state cannot be null or empty");
		}
		
		state = state.toUpperCase().trim();
		
		if (state == "PREOPEN" || state == "OPEN" || state == "CLOSED")
		{
			this.state = state;
		}
		else
		{
			throw new InvalidMarketStateException("Market state must be PREOPEN, OPEN, or CLOSED");
		}
	}
	
	public String getState()
	{
		return state;
	}
	
	public String toString()
	{
		return String.format("Market State: %s", state);
	}
}
