package trading;

@SuppressWarnings("serial")
public class ProductAlreadyExistsException extends Exception 
{
	public ProductAlreadyExistsException(String err)
	{
		super(err);
	}
}
