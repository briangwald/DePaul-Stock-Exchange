package trading;

@SuppressWarnings("serial")
public class InvalidSideException extends Exception 
{
	public InvalidSideException(String err)
	{
		super(err);
	}
}
