package trading;

@SuppressWarnings("serial")
public class InvalidIdException extends Exception 
{
	public InvalidIdException(String err)
	{
		super(err);
	}
}
