package messages;

@SuppressWarnings("serial")
public class InvalidDetailsException extends Exception 
{
	public InvalidDetailsException(String err)
	{
		super(err);
	}
}
