package messages;

import prices.Price;
import trading.InvalidIdException;
import trading.InvalidPriceException;
import trading.InvalidProductSymbolException;
import trading.InvalidSideException;
import trading.InvalidUserNameException;

public class FillMessage extends Message implements Comparable<FillMessage>
{
	public FillMessage(String userName, String productSymbol, Price price, int volume, String details, String side, String id)
			throws InvalidUserNameException, InvalidProductSymbolException,
			InvalidPriceException, InvalidVolumeException,
			InvalidDetailsException, InvalidSideException, InvalidIdException 
	{
		super(userName, productSymbol, price, volume, details, side, id);
	}

	public int compareTo(FillMessage fm) 
	{
		return this.getPrice().compareTo(fm.getPrice());
	}
}
