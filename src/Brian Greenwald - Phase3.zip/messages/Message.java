package messages;

import prices.Price;
import trading.InvalidIdException;
import trading.InvalidPriceException;
import trading.InvalidProductSymbolException;
import trading.InvalidSideException;
import trading.InvalidUserNameException;

public abstract class Message 
{
	public Message(String userName, String productSymbol, Price price, int volume, String details, String side, String id) 
			throws InvalidUserNameException, InvalidProductSymbolException, InvalidPriceException, 
			InvalidVolumeException, InvalidDetailsException, InvalidSideException, InvalidIdException
	{
		this.setUserName(userName);
		this.setProductSymbol(productSymbol);
		this.setPrice(price);
		this.setVolume(volume);
		this.setDetails(details);
		this.setSide(side);
		this.setId(id);
	}
	
	private String userName;
	
	private String productSymbol;
	
	private Price price;
	
	private int volume;
	
	private String details;
	
	private String side;
	
	private String id;
	
	private void setUserName(String userName) throws InvalidUserNameException
	{
		if (userName == null || userName == "")
		{
			throw new InvalidUserNameException("User names cannot be empty or null");
		}

		this.userName = userName.toUpperCase().trim();
		
	}
	
	private void setProductSymbol(String productSymbol) throws InvalidProductSymbolException
	{
		if (productSymbol == null || productSymbol == "")
		{
			throw new InvalidProductSymbolException("Product symbols cannot be empty or null");
		}

		this.productSymbol = productSymbol.toUpperCase().trim();
	}
	
	private void setPrice(Price price) throws InvalidPriceException
	{
		if (price == null)
		{
			throw new InvalidPriceException("Price cannot be null");
		}
		
		this.price = price;
	}
	
	public void setVolume(int volume) throws InvalidVolumeException
	{
		if (volume < 0)
		{
			throw new InvalidVolumeException("Volume cannot be less than 0");
		}
		
		this.volume = volume;
	}
	
	public void setDetails(String details) throws InvalidDetailsException
	{
		if (details == null)
		{
			throw new InvalidDetailsException("Details cannot be null");
		}
		
		this.details = details;
	}
	
	private void setSide(String side) throws InvalidSideException
	{
		side = side.toUpperCase().trim();
		
		if (side == null || side == "" || (side != "BUY" && side != "SELL"))
		{
			throw new InvalidSideException("Side must be \"BUY\" or \"SELL\"");
		}
		
		this.side = side;
	}
	
	private void setId(String id) throws InvalidIdException
	{
		if (id == null)
		{
			throw new InvalidIdException("Id cannot be null");
		}
		
		this.id = id;
	}
	
	public String getUser()
	{
		return userName;
	}
	
	public String getProduct()
	{
		return productSymbol;
	}
	
	public Price getPrice()
	{
		return price;
	}
	
	public int getVolume()
	{
		return volume;
	}
	
	public String getDetails()
	{
		return details;
	}
	
	public String getSide()
	{
		return side;
	}
	
	public String getId()
	{
		return id;
	}
	
	public String toString()
	{
		return String.format("User: %s, Product: %s, Price: %s, Volume: %d, Details: %s, "
				+ "Side: %s, Id: %s", userName, productSymbol, price.toString(), volume,
				details, side, id);
	}
}
