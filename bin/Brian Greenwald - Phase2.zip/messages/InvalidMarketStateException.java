package messages;

@SuppressWarnings("serial")
public class InvalidMarketStateException extends Exception 
{
	public InvalidMarketStateException(String err)
	{
		super(err);
	}
}
