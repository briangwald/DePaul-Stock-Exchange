package trading;

import java.util.HashMap;

import messages.FillMessage;
import messages.InvalidDetailsException;
import messages.InvalidVolumeException;

public interface TradeProcessor 
{
	public HashMap<String, FillMessage> doTrade(Tradable trd)
				throws InvalidUserNameException, InvalidProductSymbolException, InvalidPriceException, 
				InvalidVolumeException, InvalidDetailsException, InvalidSideException, InvalidIdException,
				InvalidRemainingVolumeException, InvalidCancelledVolumeException;
;
}
