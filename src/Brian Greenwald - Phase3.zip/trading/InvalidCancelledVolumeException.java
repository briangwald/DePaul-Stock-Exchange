package trading;

@SuppressWarnings("serial")
public class InvalidCancelledVolumeException extends Exception 
{
	public InvalidCancelledVolumeException(int newCancelledVolume, int remainingVolume, int originalVolume)
	{
		super(String.format("Requested new Cancelled Volume (%d) plus the Remaining Volume (%d) "
				+ "exceeds the tradable's Original Volume (%d)", newCancelledVolume, remainingVolume, originalVolume));
	}
}
