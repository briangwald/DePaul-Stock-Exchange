package trading;

import prices.Price;


public interface Tradable 
{
	public String getProduct();
	
	public Price getPrice();
	
	public int getOriginalVolume();
	
	public int getRemainingVolume();
	
	public int getCancelledVolume();
	
	public void setCancelledVolume(int newCancelledVolume) throws InvalidCancelledVolumeException;
	
	public void setRemainingVolume(int newRemainingVolume) throws InvalidRemainingVolumeException;
			
	public String getUser();
	
	public String getSide();
		
	public String getId();
	
	public boolean isQuote();

	public String toString();
}
