package trading;

@SuppressWarnings("serial")
public class DataValidationException extends Exception 
{
	public DataValidationException(String err)
	{
		super(err);
	}
}
