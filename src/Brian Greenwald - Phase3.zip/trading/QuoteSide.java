package trading;

import prices.Price;


public class QuoteSide implements Tradable 
{
	private String userName;
	
	private String productSymbol;
	
	private String id;
	
	private String side;
	
	private Price sidePrice;
	
	private int originalVolume;
	
	private int remainingVolume;
	
	private int cancelledVolume;
	
	public QuoteSide(String userName, String productSymbol, Price sidePrice, int originalVolume, String side) 
			throws InvalidOrderVolumeException, InvalidUserNameException, InvalidProductSymbolException, 
			InvalidPriceException, InvalidRemainingVolumeException, InvalidSideException, InvalidIdException
	{
		this.setUserName(userName);
		this.setProductSymbol(productSymbol);
		this.setPrice(sidePrice);
		this.setOriginalVolume(originalVolume);
		this.setRemainingVolume(originalVolume);
		this.setSide(side);
		this.setId(userName + productSymbol + System.nanoTime());
	}
	
	public QuoteSide(QuoteSide qs) 
			throws InvalidUserNameException, InvalidProductSymbolException, InvalidPriceException, 
			InvalidOrderVolumeException, InvalidRemainingVolumeException, InvalidCancelledVolumeException, 
			InvalidSideException, InvalidIdException
	{
		this.setUserName(qs.userName);
		this.setProductSymbol(qs.productSymbol);
		this.setPrice(qs.sidePrice);
		this.setOriginalVolume(qs.originalVolume);
		this.setRemainingVolume(qs.remainingVolume);
		this.setCancelledVolume(qs.cancelledVolume);
		this.setSide(qs.side);
		this.setId(userName + productSymbol + System.nanoTime());
	}
	
	@Override
	public String getProduct() 
	{
		return productSymbol;
	}

	@Override
	public Price getPrice() 
	{
		return sidePrice;
	}
	
	@Override
	public int getOriginalVolume() 
	{
		return originalVolume;
	}

	@Override
	public int getRemainingVolume() 
	{
		return remainingVolume;
	}

	@Override
	public int getCancelledVolume() 
	{
		return cancelledVolume;
	}

	@Override
	public void setCancelledVolume(int newCancelledVolume) throws InvalidCancelledVolumeException
	{
		if (newCancelledVolume > this.cancelledVolume || newCancelledVolume < 0)
		{
			throw new InvalidCancelledVolumeException(newCancelledVolume, this.remainingVolume, this.originalVolume);
		}
		
		this.cancelledVolume = newCancelledVolume;
	}

	@Override
	public void setRemainingVolume(int newRemainingVolume) throws InvalidRemainingVolumeException 
	{
		if (newRemainingVolume > this.originalVolume || newRemainingVolume < 0)
		{
			throw new InvalidRemainingVolumeException(newRemainingVolume, this.cancelledVolume, this.originalVolume);
		}
		
		this.remainingVolume = newRemainingVolume;
	}
	
	private void setOriginalVolume(int originalVolume) throws InvalidOrderVolumeException
	{
		if (originalVolume <= 0)
		{
			throw new InvalidOrderVolumeException(originalVolume);
		}
		
		this.originalVolume = originalVolume;
	}
	
	private void setUserName(String userName) throws InvalidUserNameException
	{
		if (userName == null || userName == "")
		{
			throw new InvalidUserNameException("User names cannot be empty or null");
		}

		this.userName = userName.toUpperCase().trim();
		
	}
	
	private void setProductSymbol(String productSymbol) throws InvalidProductSymbolException
	{
		if (productSymbol == null || productSymbol == "")
		{
			throw new InvalidProductSymbolException("Product symbols cannot be empty or null");
		}

		this.productSymbol = productSymbol.toUpperCase().trim();
	}
	
	private void setSide(String side) throws InvalidSideException
	{
		side = side.toUpperCase().trim();
		
		if (side == null || side == "" || (side != "BUY" && side != "SELL"))
		{
			throw new InvalidSideException("Side must be \"BUY\" or \"SELL\"");
		}
		
		this.side = side;
	}
	
	private void setPrice(Price price) throws InvalidPriceException
	{
		if (price.isMarket())
		{
			throw new InvalidPriceException("Quotes may only use Limit Prices");
		}
		
		this.sidePrice = price;
	}
	
	private void setId(String id) throws InvalidIdException
	{
		if (id == null)
		{
			throw new InvalidIdException("Id cannot be null");
		}
		
		this.id = id;
	}

	@Override
	public String getUser() 
	{
		return userName;
	}

	@Override
	public String getSide() 
	{
		return side;
	}

	@Override
	public String getId() 
	{
		return id;
	}
	
	@Override
	public boolean isQuote() 
	{
		return true;
	}
	
	public String toString()
	{
		return String.format("%s x %d (Original Vol: %d, CXL'd: %d) [%s]", 
				sidePrice.toString(), remainingVolume, originalVolume, cancelledVolume, id);
	}
	
}
