package trading;

@SuppressWarnings("serial")
public class InvalidProductBookException extends Exception 
{
	public InvalidProductBookException(String err)
	{
		super(err);
	}
}
