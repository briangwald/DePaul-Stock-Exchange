package exceptions;

public class UserNotConnectedException extends Exception 
{
	public UserNotConnectedException(String err)
	{
		super(err);
	}
}
