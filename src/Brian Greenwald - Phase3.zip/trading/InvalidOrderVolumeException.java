package trading;

@SuppressWarnings("serial")
public class InvalidOrderVolumeException extends Exception 
{
	public InvalidOrderVolumeException(int originalVolume)
	{
		super(String.format("Invalid Order Volume: %d", originalVolume));
	}
}
