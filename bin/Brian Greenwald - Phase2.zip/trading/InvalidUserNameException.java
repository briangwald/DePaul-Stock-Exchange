package trading;

@SuppressWarnings("serial")
public class InvalidUserNameException extends Exception 
{
	public InvalidUserNameException(String err)
	{
		super(err);
	}
}
