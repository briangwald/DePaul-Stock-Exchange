package trading;

@SuppressWarnings("serial")
public class InvalidProductSymbolException extends Exception 
{
	public InvalidProductSymbolException(String err)
	{
		super(err);
	}
}
