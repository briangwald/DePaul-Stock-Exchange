package messages;

@SuppressWarnings("serial")
public class InvalidVolumeException extends Exception 
{
	public InvalidVolumeException(String err)
	{
		super(err);
	}
}
